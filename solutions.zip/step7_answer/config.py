{
    'dataset_loader_train': {
        '__factory__': 'dataset.OpenML',
        'name': 'wine-quality-red',
    },

    'model_persister': {
        '__factory__': 'palladium.persistence.Database',
        'url': 'sqlite:///model.db',
    },

    'model': {
        '__factory__': 'sklearn.ensemble.RandomForestRegressor',
    },

    'grid_search': {
        'param_grid': {
            'max_depth': [None, 10, 100],
            'n_estimators': [5, 10, 100],
        },
        'cv': 2,
        'verbose': 4,
        'n_jobs': -1,
    },
}
